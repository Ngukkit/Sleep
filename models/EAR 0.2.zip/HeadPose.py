import numpy as np
import math
import cv2

# 3D 모델 포인트.
# 이 점들은 얼굴의 특정 랜드마크에 해당하는 3D 공간상의 기준점입니다.
model_points = np.array([
    (0.0, 0.0, 0.0),             # 코 끝 (Nose tip 34번 랜드마크에 해당)
    (0.0, -330.0, -65.0),        # 턱 (Chin 9번 랜드마크에 해당)
    (-225.0, 170.0, -135.0),     # 왼쪽 눈 왼쪽 끝 (Left eye left corner 37번 랜드마크에 해당)
    (225.0, 170.0, -135.0),      # 오른쪽 눈 오른쪽 끝 (Right eye right corner 46번 랜드마크에 해당)
    (-150.0, -150.0, -125.0),    # 왼쪽 입꼬리 (Left Mouth corner 49번 랜드마크에 해당)
    (150.0, -150.0, -125.0)      # 오른쪽 입꼬리 (Right mouth corner 55번 랜드마크에 해당)
])

# 행렬이 유효한 회전 행렬인지 확인합니다.
def isRotationMatrix(R):
    Rt = np.transpose(R)
    shouldBeIdentity = np.dot(Rt, R)
    I = np.identity(3, dtype=R.dtype)
    n = np.linalg.norm(I - shouldBeIdentity)
    return n < 1e-6

# 오일러 각도 계산 (pitch, yaw, roll)
def rotationMatrixToEulerAngles(R):
    sy = math.sqrt(R[0,0] * R[0,0] +  R[1,0] * R[1,0])
    
    singular = sy < 1e-6

    if not singular:
        x = math.atan2(R[2,1] , R[2,2])
        y = math.atan2(-R[2,0], sy)
        z = math.atan2(R[1,0], R[0,0])
    else:
        x = math.atan2(-R[1,2], R[1,1])
        y = math.atan2(-R[2,0], sy)
        z = 0

    # 각도를 도로 변환하여 반환 (pitch, yaw, roll 순서)
    return np.array([x, y, z]) * 180 / np.pi

def getHeadTiltAndCoords(size, image_points, frame_height):
    # 카메라 내부 파라미터 (일반적인 웹캠 값)
    focal_length = size[1] # 이미지 너비를 초점 거리로 가정
    center = (size[1]/2, size[0]/2) # 이미지 중심

    camera_matrix = np.array([
        [focal_length, 0, center[0]],
        [0, focal_length, center[1]],
        [0, 0, 1]], dtype="double")

    # 렌즈 왜곡 계수는 없다고 가정합니다. (대부분의 웹캠에서 단순화를 위해 0으로 설정)
    dist_coeffs = np.zeros((4, 1)) 
    
    # solvePnP를 사용하여 3D-2D 대응점을 통해 얼굴의 회전 벡터와 변환 벡터를 계산합니다.
    # flags=cv2.SOLVEPNP_ITERATIVE는 반복적인 해결 방법을 사용합니다.
    (success, rotation_vector, translation_vector) = cv2.solvePnP(model_points, image_points,\
                                                                  camera_matrix, dist_coeffs, \
                                                                  flags = cv2.SOLVEPNP_ITERATIVE)

    # ⭐ 중요한 오류 처리: solvePnP가 성공했는지, 벡터가 None이 아닌지 확인 ⭐
    if not success or rotation_vector is None or translation_vector is None:
        print("DEBUG: cv2.solvePnP failed to find a solution. Returning default head pose.")
        # 실패한 경우 기본값 반환하여 오류 방지
        return 0.0, 0.0, 0.0, (0, 0), (0, 0)

    # 코 끝 3D 점 (0, 0, 0)을 이미지 평면에 투영합니다. (원점)
    (nose_2d_point, jacobian) = cv2.projectPoints(np.array([(0.0, 0.0, 0.0)]), rotation_vector, translation_vector, camera_matrix, dist_coeffs)
    
    # ⭐ 중요한 오류 처리: projectPoints 결과가 유효한지 확인 (0-d 배열 방지) ⭐
    if nose_2d_point.ndim == 0 or nose_2d_point.shape != (1, 1, 2):
        print(f"DEBUG: cv2.projectPoints returned unexpected shape for nose_2d_point: {nose_2d_point.shape}. Returning default head pose.")
        return 0.0, 0.0, 0.0, (0, 0), (0, 0)

    origin_point2D = (int(nose_2d_point[0][0][0]), int(nose_2d_point[0][0][1]))

    # 3D 점 (0, 0, 1000.0)을 이미지 평면에 투영합니다. (머리 방향을 나타내는 점)
    (nose_end_point2D_raw, _) = cv2.projectPoints(np.array(
        [(0.0, 0.0, 1000.0)]), rotation_vector, translation_vector, camera_matrix, dist_coeffs)

    # ⭐ 중요한 오류 처리: projectPoints 결과가 유효한지 확인 (0-d 배열 방지) ⭐
    if nose_end_point2D_raw.ndim == 0 or nose_end_point2D_raw.shape != (1, 1, 2):
        print(f"DEBUG: cv2.projectPoints returned unexpected shape for nose_end_point2D_raw: {nose_end_point2D_raw.shape}. Returning default head pose.")
        return 0.0, 0.0, 0.0, (0, 0), (0, 0)
        
    nose_end_point2D_tuple = (int(nose_end_point2D_raw[0][0][0]), int(nose_end_point2D_raw[0][0][1]))


    # 회전 벡터로부터 회전 행렬을 얻습니다.
    rotation_matrix, _ = cv2.Rodrigues(rotation_vector)

    # 머리 기울기 각도 (피치, 요, 롤)를 도로 계산합니다.
    euler_angles = rotationMatrixToEulerAngles(rotation_matrix)
    pitch = euler_angles[0]
    yaw = euler_angles[1]
    roll = euler_angles[2]

    # 오일러 각도와 투영된 2D 포인트를 반환합니다.
    return pitch, yaw, roll, nose_end_point2D_tuple, origin_point2D

# rotationMatrixToEulerAngles 함수는 기존과 동일하게 유지합니다.
# 이 부분은 변경 없음
# rotationMatrixToEulerAngles 함수는 기존과 동일하게 유지합니다.
def rotationMatrixToEulerAngles(R):
    # isRotationMatrix 함수를 사용하여 R이 유효한 회전 행렬인지 확인하는 것이 좋습니다.
    # 하지만 여기서는 간단화를 위해 생략합니다.
    
    sy = math.sqrt(R[0,0] * R[0,0] +  R[1,0] * R[1,0])
    
    singular = sy < 1e-6

    if not singular:
        x = math.atan2(R[2,1] , R[2,2])
        y = math.atan2(-R[2,0], sy)
        z = math.atan2(R[1,0], R[0,0])
    else:
        x = math.atan2(-R[1,2], R[1,1])
        y = math.atan2(-R[2,0], sy)
        z = 0

    # 각도를 도로 변환하여 반환 (pitch, yaw, roll 순서)
    return np.array([x, y, z]) * 180 / np.pi